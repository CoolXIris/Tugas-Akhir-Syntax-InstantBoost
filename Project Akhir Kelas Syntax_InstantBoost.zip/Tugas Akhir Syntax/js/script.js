function changeButtonColor(button, color) {
  button.style.backgroundColor = color;
  button.style.transition = ".5s ease";
}

const buttons = document.querySelectorAll(".payment-denom-button");

buttons.forEach((button) => {
  button.addEventListener("click", () => {
    buttons.forEach((otherButton) => {
      otherButton.classList.remove("active");
      otherButton.style.color = "white";
      changeButtonColor(otherButton, "");
    });

    button.classList.add("active");

    button.style.color = "white";

    changeButtonColor(button, "#f97d00");
  });
});

// payment-button option

// Get all payment option buttons
const paymentButtons = document.querySelectorAll(".payment-option-button");

// Add click event listener to each button
paymentButtons.forEach((button) => {
  button.addEventListener("click", changeButtonColor);
});

// Function to change button color
function changeButtonColor(event) {
  // Get the clicked button
  const clickedButton = event.target;

  // Remove active class from all buttons
  paymentButtons.forEach((button) => {
    button.classList.remove("active");
  });

  // Add active class to the clicked button
  clickedButton.classList.add("active");
}

// pop-up tombol beli

document.addEventListener("DOMContentLoaded", () => {
  const alertTrigger = document.querySelector(".alert-trigger");

  alertTrigger.addEventListener("click", (event) => {
    event.preventDefault(); // Mencegah redirect default

    Swal.fire({
      title: "Apa Kamu Sudah Yakin?",
      text: "Kamu Tidak Bisa Mengubah Data Lagi Setelah Mengkonfirmasi!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Ya, Konfirmasi!",
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.fire({
          title: "Berhasil!",
          text: "Top Up Kamu Sudah Berhasil.",
          icon: "success",
        }).then(() => {
          Swal.fire(
            "Silahkan login dan cek apakah Top Up nya sudah masuk ke akun game mu >_<"
          ).then(() => {
            window.location.href = alertTrigger.href; // Redirect ke halaman payment.html
          });
        });
      }
    });
  });
});

// fitur belum tersedia
document.querySelectorAll(".alert-trigger2").forEach(function (element) {
  element.addEventListener("click", function (event) {
    // Prevent the default action (navigation)
    event.preventDefault();

    // Show the SweetAlert2 alert
    Swal.fire({
      icon: "error",
      title: "Oops...",
      text: "Fitur Ini Masih Belum Tersedia, Nantikan Update Terbaru dari Kami!",
    });
  });
});
