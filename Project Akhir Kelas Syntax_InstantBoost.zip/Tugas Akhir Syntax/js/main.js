let next = document.querySelector(".next");
let prev = document.querySelector(".prev");

next.addEventListener("click", function () {
  let items = document.querySelectorAll(".item");
  document.querySelector(".slide").appendChild(items[0]);
});

prev.addEventListener("click", function () {
  let items = document.querySelectorAll(".item");
  document.querySelector(".slide").prepend(items[items.length - 1]);
});

function moveNext() {
  let items = document.querySelectorAll(".item");
  document.querySelector(".slide").appendChild(items[0]);
}

setInterval(moveNext, 2500);

// Select all elements with the class 'alert-trigger'
document.querySelectorAll(".alert-trigger").forEach(function (element) {
  element.addEventListener("click", function (event) {
    // Prevent the default action (navigation)
    event.preventDefault();

    // Show the SweetAlert2 alert
    Swal.fire({
      icon: "error",
      title: "Oops...",
      text: "Fitur Ini Masih Belum Tersedia, Nantikan Update Terbaru dari Kami!",
    });
  });
});
// pop-up message

document.addEventListener("DOMContentLoaded", (event) => {
  const steps = ["1", "2", "3"];
  const Queue = Swal.mixin({
    progressSteps: steps,
    confirmButtonText: "Next >",
    showClass: { backdrop: "swal2-noanimation" },
    hideClass: { backdrop: "swal2-noanimation" },
  });

  function blurBackground() {
    document.getElementById("content").classList.add("blur");
  }

  function unblurBackground() {
    document.getElementById("content").classList.remove("blur");
  }

  async function showPromoAlerts() {
    blurBackground();
    await Queue.fire({
      title: "Promo 1",
      currentProgressStep: 0,
      imageUrl: "./img/promo1.png",
      imageWidth: 400,
      imageHeight: 200,
      imageAlt: "Promo 1",
    });
    await Queue.fire({
      title: "Promo 2",
      currentProgressStep: 1,
      imageUrl: "./img/promo2.png",
      imageWidth: 400,
      imageHeight: 200,
      imageAlt: "Promo 2",
    });
    await Queue.fire({
      title: "Promo 3",
      currentProgressStep: 2,
      confirmButtonText: "OK",
      imageUrl: "./img/promo3.png",
      imageWidth: 400,
      imageHeight: 200,
      imageAlt: "Promo 3",
    });
    unblurBackground();
  }

  showPromoAlerts();
});
